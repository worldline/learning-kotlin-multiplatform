package network.data

data class Quiz(var questions: List<Question>)