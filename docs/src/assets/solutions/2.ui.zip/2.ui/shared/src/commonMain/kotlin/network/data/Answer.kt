package network.data

data class Answer(val id: Int, val label: String )