package com.worldline.quiz.data.dataclass

data class Answer(val id: Int, val label: String )