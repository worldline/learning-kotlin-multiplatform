package com.worldline.quiz.data.dataclass

data class Quiz(var questions: List<Question>)