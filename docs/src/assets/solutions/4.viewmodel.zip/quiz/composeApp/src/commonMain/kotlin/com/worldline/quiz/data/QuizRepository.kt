package com.worldline.quiz.data

import com.worldline.quiz.data.dataclass.Question
import com.worldline.quiz.data.datasources.MockDataSource

class QuizRepository  {
    private val mockDataSource = MockDataSource()
    fun updateQuiz():List<Question>{
            return mockDataSource.generateDummyQuestionsList()
    }
}