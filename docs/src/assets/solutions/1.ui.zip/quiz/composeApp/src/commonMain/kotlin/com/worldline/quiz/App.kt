package com.worldline.quiz


import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.*
import com.worldline.quiz.data.dataclass.Answer
import com.worldline.quiz.data.dataclass.Question
import org.jetbrains.compose.ui.tooling.preview.Preview


@Composable
@Preview
fun App() {
    MaterialTheme {
        val questions = listOf(
            Question(
                1,
                "Android is a great platform ?",
                1,
                listOf(Answer(1, "YES"), Answer(2, "NO"))
            ),
            Question(
                1,
                "Android is a bad platform ?",
                2,
                listOf(Answer(1, "YES"), Answer(2, "NO"))
            )
        )
        questionScreen(questions)
    }
}