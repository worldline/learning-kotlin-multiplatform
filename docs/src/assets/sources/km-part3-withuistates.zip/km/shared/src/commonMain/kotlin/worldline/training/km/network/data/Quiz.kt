package worldline.training.km.network.data

data class Quiz(var questions: List<Question>)
