package com.devoxxfr2023.km.network.data

import com.devoxxfr2023.km.network.data.Answer


data class Question(val id:Int, val label:String, val correctAnswerId:Int, val answers:List<Answer>)
