
import com.devoxxfr2023.km.Greeting

fun main() {
        var greet = Greeting().greet()
        println(greet)
}
