
import worldline.training.km.Greeting

fun main() {
        var greet = Greeting().greet()
        println(greet)
}
