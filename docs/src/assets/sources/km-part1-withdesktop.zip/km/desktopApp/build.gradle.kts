
plugins {
    kotlin("multiplatform")
    application
}

group = "worldline.training.km"
version = "1.0-SNAPSHOT"

kotlin {
    jvm {
        jvmToolchain(11)
        withJava()

    }
    sourceSets {
        val jvmMain by getting {
            dependencies {
                implementation(project(":shared"))
            }

        }
    }

}

application{
    mainClass.set("MainKt")
}


