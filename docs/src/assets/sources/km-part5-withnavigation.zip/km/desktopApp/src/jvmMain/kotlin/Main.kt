
import androidx.compose.ui.window.application
import worldline.training.km.DesktopApp
import moe.tlaster.precompose.PreComposeWindow

fun main() = application { // kotlin application
        PreComposeWindow(onCloseRequest = ::exitApplication, title = "QuizzApp") {
                DesktopApp() // composable view shared
        }
}