package worldline.training.km

import androidx.compose.runtime.Composable

@Composable
fun AndroidApp() {
    App()
}