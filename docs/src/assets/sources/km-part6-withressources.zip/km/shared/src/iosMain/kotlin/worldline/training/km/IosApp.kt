package worldline.training.km

import moe.tlaster.precompose.PreComposeApplication
import platform.UIKit.UIViewController

fun MainViewController(): UIViewController =
    PreComposeApplication("QuizApp") {
        App()
    }