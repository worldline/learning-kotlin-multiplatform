package com.devoxxfr2023.km

import androidx.compose.runtime.Composable

@Composable
fun AndroidApp() {
    App()
}