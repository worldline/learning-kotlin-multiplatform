package worldline.training.km

import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.material.Text

@Composable
internal fun App() {
    MaterialTheme {
        Text("Hello world")
    }
}