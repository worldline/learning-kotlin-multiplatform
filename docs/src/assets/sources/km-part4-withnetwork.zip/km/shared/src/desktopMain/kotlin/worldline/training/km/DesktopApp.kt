package worldline.training.km

import androidx.compose.runtime.Composable

@Composable
fun DesktopApp() {
    App()
}